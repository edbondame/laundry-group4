package net.javawookies.laundryShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaundryShopBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaundryShopBackendApplication.class, args);
	}

}
