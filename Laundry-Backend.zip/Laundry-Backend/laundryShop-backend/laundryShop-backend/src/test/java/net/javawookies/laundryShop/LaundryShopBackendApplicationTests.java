package net.javawookies.laundryShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaundryShopBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
