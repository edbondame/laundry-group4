export const environment = {
    production: false,
    apiUrl: 'https://mock-api.binaryboxtuts.com/',
    apiKey: 'binarybox_api_key_VzO8M31mfzUAW58MBuDkyVX68IWufWJWW7m5BqqSi3FSXHHwKeHjuXQzOC7QdACzffplQ93npFb6Q3sMQLeImXxkz3IHQDkWy1yt'
};